from .client import DgteraClient as DgtClient
from .client import DgteraPOSClient as DgtPOSClient
from .exceptions import DgtException